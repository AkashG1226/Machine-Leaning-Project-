# Titanic-dataset-analysis-with-Tableau
Titanic dataset is collected from kaggle
At first, whether age,passenger class,sibling/spouse has effect on the survival is tested.

Color Blue stands for people survived, and Orange Stands for not survived.

For testing effect of age:
  Age bin of 10 is taken along the row and count of passenger along column.
  Survived is converted to dimension. It is seen that amount of survival varies significantly with respect to age. 

Similarly effect of other factors class,sibling/spouse has been verified. 

Finally a dashboard is created. 
  
