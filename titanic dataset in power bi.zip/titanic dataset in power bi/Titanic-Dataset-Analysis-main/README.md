# Titanic-Dataset-Analysis
## Table of contants
- [Project overview](#project-overview)
- [Data sources](#data-sources)
- [Tools](#tools)

### project overview
This project involves a comprehensive analysis of the Titanic dataset using Python for data gathering, assessment, cleaning, and visualization. After completing the analysis, an interactive dashboard was created in Power BI to visualize key insights. The project demonstrates proficiency in data wrangling, analysis, and dashboard creation.

### Data sources
the primery dataset used for this analysis is the " olympics2024.csv " file , containing dataild information about all people and number of survaived on the ship
### Tools
- Jupytar notebook : python for data analysis
- Power BI : makink the dashboard
### Data cleaning / preparation 
in intial data preparation phase , we preformed the followng tasks :
1. Data loading and inspection
2. Handling the missing values

### Explory data analysis 
EDA involved exploring the olympics data to answar key question , such as :

- What is the number of deaths based on gender?
- What is the most destroyed class?


### kaggle notebook link : [click here](https://www.kaggle.com/code/reemkasaab/titanic)
